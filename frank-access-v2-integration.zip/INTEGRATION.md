# Frank Denied Access — V2 integration

**Status: installation patch, not merged into GitHub.** Upload only to the `habbo-fansite-v2` branch and test on staging. Do not change `main`.

1. Copy the supplied files into `v2/` by matching paths. Existing V2 sites: import `v2/database/009_access_denials.sql` in phpMyAdmin.
2. Fresh installs: in `v2/public/setup.php` add `'009_access_denials.sql'` to the SQL filename array.
3. In `v2/app/bootstrap.php`, immediately after `require_once __DIR__.'/discord.php';` add:
   `require_once __DIR__.'/access-denial.php';`
4. In `require_login()`, replace the existing line:
   `if(!discord_authorised($pdo,$config,$did)){unset($_SESSION['discord_verified_at']);http_response_code(403);exit('Discord role access denied. Contact the fansite owner.');}`
   with:
   `if(!discord_authorised($pdo,$config,$did)){unset($_SESSION['discord_verified_at']);deny_panel_access($pdo,(int)$me['id'],'discord_role_unverified');}`
   This logs failed Discord role/API checks and redirects to the standalone Frank page.
5. In `v2/public/dashboard.php`, next to the owner-only Session Audit link, add:
   `<a href="access-log.php">Denied Access Log</a>`
6. Set up a **daily** cPanel CLI cron for the `v2/cron/purge-access-logs.php` cleanup to delete denial events older than 30 days.
7. Test a denied Discord-role session, confirm HTTP 403 at Frank page, and verify the date/time/IP appear in owner-only access logs. A network/API error also counts as unverified: the system intentionally fails closed.
8. Session IPs in `staff_sessions` are separate and currently persist beyond 30 days; define and enforce their retention separately.
9. IP addresses are personal data. Add the recording purpose and retention to the site's privacy notice. Only trust `REMOTE_ADDR` unless a trusted reverse proxy is configured properly.
10. Protect the log page with the existing `require_login()` and an owner-only role check. Never link raw logs publicly.

The Frank page deliberately avoids bootstrap to prevent redirect loops.
